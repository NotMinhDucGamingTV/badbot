const { ActionRowBuilder, ButtonStyle, ModalBuilder, TextInputBuilder, TextInputStyle,EmbedBuilder,ButtonBuilder,InteractionType } = require("discord.js");
module.exports = async(interaction, client) => {
    const { OwnerID } = process.env
    if (interaction.type == InteractionType.ApplicationCommand) {
        const command = client.slash.get(interaction.commandName);
        if (!command) return interaction.reply({ content: 'an Erorr' });

        if (command.ownerOnly) {
            if (!interaction.member.user.id == OwnerID) {
                return interaction.reply('Command under developement!')
            }
        }

        if (command.userPerms) {
            if (!client.guilds.cache.get(interaction.guild.id).members.cache.get(interaction.member.id).permissions.has(command.userPerms || [])) {
                if (command.noUserPermsMessage) {
                    return interaction.reply(command.noUserPermsMessage)
                } else if (!command.noUserPermsMessage) {
                    return interaction.reply(`You need the \`${command.userPerms}\` permission to use this command!`)
                }
            }
        }

        if (command.botPerms) {
            if (!client.guilds.cache.get(interaction.guild.id).members.cache.get(client.user.id).permissions.has(command.botPerms || [])) {
                if (command.noBotPermsMessage) {
                    return interaction.reply(command.noBotPermsMessage)
                } else if (!command.noBotPermsMessage) {
                    return interaction.reply(`I need the \`${command.userPerms}\` permission to execute this command!`)
                }
            }
        } 

        const args = [];

        for (let option of interaction.options.data) {
            if (option.type === 'SUB_COMMAND') {
                if (option.name) args.push(option.name);
                option.options?.forEach(x =>  {
                    if (x.value) args.push(x.value);
                });
            } else if (option.value) args.push(option.value);
        }

        try {
            command.run(client, interaction, args)
        } catch (e) {
            interaction.reply({ content: e.message });
        }
    } else if (interaction.isButton()) {
      if (interaction.customId == "search_box") {
        const modal = new ModalBuilder()
			.setCustomId('SearchModal')
			.setTitle('Search');
		const searchkeywordinput = new TextInputBuilder()
			.setCustomId('searchkeyword')
			.setLabel("What's the keyword?")
			.setStyle(TextInputStyle.Short);
		const firstActionRow = new ActionRowBuilder().addComponents(searchkeywordinput);
		modal.addComponents(firstActionRow);
		await interaction.showModal(modal);
      }
    } else if (interaction.isModalSubmit()) {
      const searchkeyword = interaction.fields.getTextInputValue('searchkeyword');
      if (searchkeyword == "Embed1") {
        const embed = new EmbedBuilder()
    .setTitle("Embed 1")
    .setDescription("You Found me!")
    await interaction.reply({embeds: [embed],ephemeral: true})
      } else if (searchkeyword == "Embed2") {
        const embed = new EmbedBuilder()
    .setTitle("Embed 2")
    .setDescription("You Found me!")
    await interaction.reply({embeds: [embed],ephemeral: true})
      } else if (searchkeyword == "Author") {
        const embed = new EmbedBuilder()
    .setTitle("Code author")
    .setDescription("MinhDucGoneMissing!")
    await interaction.reply({embeds: [embed],ephemeral: true})
      }
    }
}