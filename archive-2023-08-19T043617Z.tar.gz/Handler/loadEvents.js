const clientEvent = (event) => require(`../Event/client/${event}`);
const guildEvent = (event) => require(`../Event/guild/${event}`);
const musicEvent = (event) => require(`../Event/Music/${event}`);
const Discord = require("discord.js");

function loadEvents(client) {
  const cooldowns = new Discord.Collection();
  client.on('interactionCreate', (m) => guildEvent("interactioncreate")(m, client));
  // warnings and errors
  client.on("warn", (info) => console.log(info));
  client.on("error", console.error);
}

module.exports = {
  loadEvents,
};