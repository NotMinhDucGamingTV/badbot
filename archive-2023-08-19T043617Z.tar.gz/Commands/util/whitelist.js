const { ActionRowBuilder, ButtonStyle, ModalBuilder, TextInputBuilder, TextInputStyle,EmbedBuilder,ButtonBuilder } = require('discord.js');
const WhiteListDataModel = require("../../Datastore/whitelist")
module.exports = {
  name: "whitelist",
  description: "whitelist a channel to force command in that channel only (one per server)!",
  options: null,
  run: async (client, interaction, args) => {
        const data = await WhiteListDataModel.findOne({
        ServerID: interaction.guild.id
    })
    console.log(data)
    if (data) {
      data.Channel = interaction.channelId
        data.save()
     const embed = new EmbedBuilder()
    .setTitle("System")
    .setDescription(`Changed whitelisted channel to ${interaction.channelId}`)
    .setFooter({text: "Empowered by harumari's system"})
    await interaction.reply({embeds: [embed]})
      } else {
    const data = new WhiteListDataModel({
        ServerID: interaction.guild.id,
        Channel: interaction.channelId
    })
    data.save()
          const embed = new EmbedBuilder()
    .setTitle("System")
    .setDescription(`Changed whitelisted channel to ${interaction.channelId}`)
    .setFooter({text: "Empowered by harumari's system"})
    await interaction.reply({embeds: [embed]})
      }
  }
};



