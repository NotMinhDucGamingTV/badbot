const { ActionRowBuilder, ButtonStyle, ModalBuilder, TextInputBuilder, TextInputStyle,EmbedBuilder,ButtonBuilder } = require('discord.js');
const WhiteListDataModel = require("../../Datastore/whitelist")
module.exports = {
  name: "getscript",
  description: "Script here!",
  options: null,
  run: async (client, interaction, args) => {
    const data = await WhiteListDataModel.findOne({
        ServerID: interaction.guild.id
    })
    console.log(data)
    if (data) {
            if (interaction.channelId == data.Channel) {
    await interaction.reply("Please wait, proccessing...")
    try {
    await interaction.user.send("```repeat wait() until game:IsLoaded() \
loadstring(game:HttpGet('https://raw.githubusercontent.com/KelvinCod/SkidHub/main/Luncher.lua'))()```")
    await interaction.user.send("Copy this script into your favorite exploit and run it. ")
      const embed2 = new EmbedBuilder()
    .setTitle("Done!")
    .setDescription("The script have been delivered to your DM")
    .setFooter({text: "Empowered by harumari's system™"})
    await interaction.editReply({ content: "", embeds: [embed2]})
    } catch (err){
      const embed2 = new EmbedBuilder()
    .setTitle("Script!")
    .setDescription("```repeat wait() until game:IsLoaded() \
loadstring(game:HttpGet('https://raw.githubusercontent.com/KelvinCod/SkidHub/main/Luncher.lua'))()```")
    .setFields({name:"Why here?", value: "Beacause Your DM was closed",inline:false})
    .setFooter({text: "Empowered by harumari's system™"})
    await interaction.editReply({ content: "", embeds: [embed2],ephemeral: true})
    }
    } else {
              interaction.reply({content: "command are not allowed at here",ephemeral: true})
        }
      } else {
          await interaction.reply("Please wait, proccessing...")
    try {
    await interaction.user.send("```repeat wait() until game:IsLoaded() \
loadstring(game:HttpGet('https://raw.githubusercontent.com/KelvinCod/SkidHub/main/Luncher.lua'))()```")
    await interaction.user.send("Copy this script into your favorite exploit and run it. ")
      const embed2 = new EmbedBuilder()
    .setTitle("Done!")
    .setDescription("The script have been delivered to your DM")
    .setFooter({text: "Empowered by harumari's system™"})
    await interaction.editReply({ content: "", embeds: [embed2]})
    } catch (err){
      const embed2 = new EmbedBuilder()
    .setTitle("Script!")
    .setDescription("```repeat wait() until game:IsLoaded() \
loadstring(game:HttpGet('https://raw.githubusercontent.com/KelvinCod/SkidHub/main/Luncher.lua'))()```")
    .setFields({name:"Why here?", value: "Beacause Your DM was closed",inline:false})
    .setFooter({text: "Empowered by harumari's system™"})
    await interaction.editReply({ content: "", embeds: [embed2],ephemeral: true})
  }
  }
}
}
