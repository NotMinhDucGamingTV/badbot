const { ActionRowBuilder, ButtonStyle, ModalBuilder, TextInputBuilder, TextInputStyle,EmbedBuilder,ButtonBuilder } = require('discord.js');
const WhiteListDataModel = require("../../Datastore/whitelist")
module.exports = {
  name: "funfact",
  description: "fun fact!",
  options: null,
  run: async (client, interaction, args) => {
    const data = await WhiteListDataModel.findOne({
        ServerID: interaction.guild.id
    })
    console.log(data)
    if (data) {
            if (interaction.channelId == data.Channel) {
    const embed = new EmbedBuilder()
    .setTitle("About Badtime!")
    .setDescription(`1.He tooked years to fix the script page, incoperate with a thais and vietnamese dev
    2.He used botghost cuz he are lazy and dont now how to code
    3. Look at the footer, this is a gift from harumari after he/she laughed out loud when get to know that badtime use botghost`)
    .setFooter({text: "Empowered by harumari's system"})
    await interaction.reply({embeds: [embed]})
        } else {
              interaction.reply({content: "command are not allowed at here",ephemeral: true})
        }
      } else {
      const embed = new EmbedBuilder()
    .setTitle("About Badtime!")
    .setDescription(`1.He tooked years to fix the script page, incoperate with a thais and vietnamese dev
    2.He used botghost cuz he are lazy and dont now how to code
    3. Look at the footer, this is a gift from harumari after he/she laughed out loud when get to know that badtime use botghost`)
    .setFooter({text: "Empowered by harumari's system"})
    await interaction.reply({embeds: [embed]})
    }
  },
};
