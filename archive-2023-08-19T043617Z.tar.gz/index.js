const dotenv = require("dotenv")
dotenv.config()
const { Client, Collection, EmbedBuilder, Events, GatewayIntentBits } = require('discord.js');
const { loadEvents } = require("./Handler/loadEvents");
const { loadCommands } = require("./Handler/loadCommands");
const client = new Client({
  allowedMentions: { parse: ["users", "roles"] },
  intents: 3276799
})
const mongoose = require('mongoose');
mongoose.connect(process.env.mongodlink, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});
client.commands = new Collection();
client.slash = new Collection();
client.aliases = new Collection();
loadCommands(client)
loadEvents(client)
const express = require('express')
const app = express()
const port = process.env["SERVER_PORT"]
app.get('/dump_cai_dau_buoi', (req, res) => {
    const fs = require('fs');
fs.readFile('UiLib.txt', 'utf8', (err, data) => {
  if (err) {
    res.send(err)
    return;
  }
  res.send(data)
});
})
app.get('/badhublovler', (req, res) => {

    const fs = require('fs');
//upfile thì thay uilib sang cái khác
fs.readFile('UiLib.txt', 'utf8', (err, data) => {

  if (err) {

    res.send(err)

    return;

  }

  res.send(data) // không thì xóa bên trên thay chỗ này thành string

});

})
app.listen(port, () => {
  console.log(`Example app listening on port ${port}`)

})
client.login(process.env.TOKEN).then(() => {
  client.user.setStatus('idle'); // more status 'idle' or 'online' ^^
  client.user.setActivity('Payday 3');
  //client.user.setActivity({ name: 'a game', type: 'PLAYING' })
})


