const mongoose = require('mongoose');
const levelModel = module.exports = mongoose.model('whitelist', {
  ServerID: String,
  Channel:String, 
});